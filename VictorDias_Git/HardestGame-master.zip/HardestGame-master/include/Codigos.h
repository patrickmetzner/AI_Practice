/********************************
Teclado:

Codigos a��es:

768 = Tecla pressionada             (ESC, Enter, Alt, Shift, F1, Tab)
769 = Tecla soltada                 (Qualquer tecla)
771 = Letra ou numero pressionado   (de A at� Z, de 0 at� 9)

Codigos teclas:

82 =    Seta cima
81 =    Seta baixo
80 =    Seta esquerda
79 =    Seta direita
40 =    Enter
41 =    Esc
42 =    Backspace
44 =    Space
29 =    Z
4 =     A
30 =    1
38 =    9
58 =    F1
69 =    F12
225 =   Left shift
229 =   Right shift
224 =   Left control
226 =   Left alt
230 =   Alt gr

Mouse:

Codigo a��es:

1024 = Mover cursor
1025 = Apertando bot�o
1026 = Soltar bot�o
1027 = Rolar scroll

Codigo bot�es:

1 = Bot�o esquerdo
2 = Bolinha do meio
3 = Botao direito
/********************************/
