

    char* AvisoMovimento[3] =   {"Movimentos desativados!",     " ",    "Movimentos ativados!"};
    char* AvisoTrajetoria[3] =  {"Trajetoria desativada!",      " ",    "Trajetoria ativada!"};
    char* AvisoColisao[3] =     {"Colisao desativada!", "Colisao elastica ativada!", "Colisao inelastica ativada!"};
    char* AvisoEspaco[4] =      {"Campo desativado!", "Campo1 ativado!", "Campo2 ativado!", "Campo3 ativado!"};

    int SpritesExplosao[15];

    char* SpriteExplosaoPath[15] = {    "imagens\\Explosao\\1.png",
                                        "imagens\\Explosao\\2.png",
                                        "imagens\\Explosao\\3.png",
                                        "imagens\\Explosao\\4.png",
                                        "imagens\\Explosao\\5.png",
                                        "imagens\\Explosao\\6.png",
                                        "imagens\\Explosao\\7.png",
                                        "imagens\\Explosao\\8.png",
                                        "imagens\\Explosao\\9.png",
                                        "imagens\\Explosao\\10.png",
                                        "imagens\\Explosao\\10.png",
                                        "imagens\\Explosao\\11.png",
                                        "imagens\\Explosao\\11.png",
                                        "imagens\\Explosao\\12.png",
                                        "imagens\\Explosao\\12.png"  };




